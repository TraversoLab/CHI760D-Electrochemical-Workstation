The free and open-source libec-vi-repo project hosts LabVIEW virtual 
instruments (VI's) for use with the CH Instruments libec SDK, which 
allows you to control CH Instruments hardware from LabVIEW.

The libec-vi-repo project is offered under the LGPL (v2). 

These VI's require the libec SDK to run. To obtain the libec SDK, 
please visit 
http://www.chinstruments.com/libec_alpha.shtml

Visit the libec-vi-repo project website at
http://sourceforge.net/projects/libec-vi-repo/

Contents
- about.vi: "Hello Libec"
- chi.vi: uses Labview 'native' GUI
- chi_controls.llb: technique/parameter controls
- chi_input.llb: VI's involved with sending input to libec.dll
- chi_output.llb: VI's involved with receiving output from libec.dll
- chi_system.llb: libec "system" VI's
- demo.vi: uses libec 'built-in' GUI

Minimum libec version required: 0.1.4

Copyright (c) 2017 CH Instruments, Inc.

Current Subversion revision number: 50
